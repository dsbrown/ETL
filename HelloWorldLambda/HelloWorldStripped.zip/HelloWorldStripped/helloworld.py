'''
###################################################################################
                        Hello World Python Lambda Test
                            helloworld.py
Author: David S. Brown
All Rights Reserved 17 July 2018
####################################################################################
'''

#############################################
#          main lambda_handler
#############################################
def lambda_handler(event, context):
    # TODO implement
    return 'Hello World from Deployment Package'